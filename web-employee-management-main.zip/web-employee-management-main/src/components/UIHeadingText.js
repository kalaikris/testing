function UIHeadingText(props) {
  return <h3>{props.name}</h3>;
}

export default UIHeadingText;
