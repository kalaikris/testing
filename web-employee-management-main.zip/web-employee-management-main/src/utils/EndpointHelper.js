const adminLogin = "login";
const getEmployees = "employee";
const getDepartments = "department";
const addEmployee = "employee";
const addDepartment = "department";

export { adminLogin, getEmployees, getDepartments, addEmployee, addDepartment };
